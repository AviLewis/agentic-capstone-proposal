import { z } from 'zod';
import { canonicalizeUrl } from './url.js';
import type { SourceAdapter } from './source-adapter.js';
import type { FetchOptions, JsonFetcher } from './http.js';
import type { RawItem } from '../domain/types.js';

const BASE = 'https://api.gdeltproject.org/api/v2/doc/doc';
const DEFAULT_QUERY =
  '(geopolitics OR diplomacy OR conflict OR sanctions OR election OR economy)';

const responseSchema = z.object({
  articles: z
    .array(
      z.object({
        url: z.string(),
        title: z.string().optional(),
        seendate: z.string().optional(),
      }),
    )
    .optional(),
});

/** GDELT seendate "YYYYMMDDTHHMMSSZ" → epoch ms (null if unparseable). The regex
 * checks format, not calendar validity, so an impossible date (month 13) parses to
 * NaN — which libsql rejects and would fail the whole tick's persist (ADR-0051). */
function parseSeenDate(s: string | undefined): number | null {
  if (!s) return null;
  const m = /^(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z$/.exec(s);
  if (!m) return null;
  const t = Date.parse(`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`);
  return Number.isFinite(t) ? t : null;
}

/**
 * GDELT's doc API is legitimately slow — an artlist call routinely takes ~13s,
 * over the 10s global fetch timeout (ADR-0039). Give it a generous per-request
 * timeout so the world-news feed doesn't time out every tick. Ticks are minutes
 * apart, so this never bumps GDELT's ~1-req/5s limit.
 */
const GDELT_TIMEOUT_MS = 25_000;

/**
 * Wait before the single retry after a transient GDELT failure. GDELT enforces
 * ~1 req / 5s; the shared per-host limiter (rateLimitByHost) spaces the story
 * feed and the tone signal, but its spacing is measured client-side, so a
 * marginal request can still land inside GDELT's server-side window and 429 —
 * on the live tick that lost BOTH the feed and the signal. `JsonFetcher` doesn't
 * expose response headers, so instead of honoring Retry-After we wait a fixed
 * interval comfortably over the 5s policy. Ticks are minutes apart; +7s is cheap.
 */
export const GDELT_RETRY_DELAY_MS = 7_000;

/**
 * True for failures worth exactly ONE retry: GDELT's 429 rate-limit response and
 * a transient network drop (undici's generic `fetch failed`). Anything else
 * (404/5xx, timeouts, schema errors) surfaces immediately as a failed source.
 */
export function isTransientGdeltError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return /failed: 429\b/.test(msg) || /\bfetch failed\b/i.test(msg);
}

/**
 * One fetch with a single retry on a transient failure. The retry goes back
 * through the caller's (rate-limited) fetcher, so it is re-spaced against any
 * other in-flight GDELT call rather than piling on.
 */
export async function gdeltFetch(
  fetchJson: JsonFetcher,
  url: string,
  options: FetchOptions,
  retryDelayMs: number = GDELT_RETRY_DELAY_MS,
): Promise<unknown> {
  try {
    return await fetchJson(url, options);
  } catch (err) {
    if (!isTransientGdeltError(err)) throw err;
    await new Promise((r) => setTimeout(r, retryDelayMs));
    return fetchJson(url, options);
  }
}

export interface GdeltDeps {
  readonly fetchJson: JsonFetcher;
  readonly maxItems: number;
  /** GDELT query string (defaults to a broad geopolitics/world query). */
  readonly query?: string;
  /** Per-request timeout override; GDELT is slow, so default to a generous value. */
  readonly timeoutMs?: number;
  /** Delay before the single 429/transient retry; injectable for tests. */
  readonly retryDelayMs?: number;
}

/**
 * GDELT 2.1 Doc API adapter (ADR-0004). Global news/events feed. Leaves
 * Topic to the classifier (ADR-0009) — GDELT's sourcecountry is the
 * publisher, not the story's subject. Respect GDELT's 1-request/5-second limit
 * (one call per tick).
 */
export class GdeltSource implements SourceAdapter {
  readonly id = 'gdelt' as const;

  constructor(private readonly deps: GdeltDeps) {}

  private url(maxRecords: number): string {
    const query = encodeURIComponent(this.deps.query ?? DEFAULT_QUERY);
    return `${BASE}?query=${query}&mode=artlist&format=json&sort=DateDesc&maxrecords=${maxRecords}`;
  }

  /**
   * No pre-flight probe (ADR-0039). GDELT enforces ~1 request / 5 seconds, so a
   * healthCheck fetch here followed immediately by the extract fetch is two calls
   * back-to-back — which trips the limit and is exactly why GDELT skipped every
   * tick. Return true so extract() makes the single request the API allows; the
   * pipeline's try/catch still isolates a genuinely-down GDELT as a `failed`
   * source (with its error), rather than a silent skip.
   */
  async healthCheck(): Promise<boolean> {
    return true;
  }

  async extract(): Promise<RawItem[]> {
    const parsed = responseSchema.parse(
      await gdeltFetch(
        this.deps.fetchJson,
        this.url(this.deps.maxItems),
        { timeoutMs: this.deps.timeoutMs ?? GDELT_TIMEOUT_MS },
        this.deps.retryDelayMs,
      ),
    );
    return (parsed.articles ?? [])
      .filter((a) => a.title)
      .map((a) => ({
        source: 'gdelt' as const,
        // GDELT reprints the same article URL with varying params; canonicalize
        // so one article is one id across ticks (ADR-0047).
        externalId: canonicalizeUrl(a.url),
        title: a.title as string,
        url: a.url,
        text: null,
        publishedAt: parseSeenDate(a.seendate),
        metadata: {},
      }));
  }
}
