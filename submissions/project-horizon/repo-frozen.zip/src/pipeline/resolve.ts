import { representativeOf, storyIdOf } from '../domain/cluster.js';
import { cosine } from '../embedding/cosine.js';
import { dedupText } from './embed.js';
import { extractEntities, sharedEntityStats } from './entities.js';
import { DEFAULT_CONFIRM_CONCURRENCY, mapWithConcurrency } from './concurrency.js';
import type { Cluster, RawItem, RawItemRef, Topic } from '../domain/types.js';
import type { StoredVector, StoryRepo } from '../db/story-repo.js';
import type { RawItemRepo } from '../db/raw-item-repo.js';
import type { PipelineReasoner } from '../llm/llm-client.js';
import type { Clock } from '../scheduler/clock.js';
import { nullLogger, type Logger } from '../log/logger.js';
import type { EmbeddedItem } from './types.js';

const HOUR_MS = 3_600_000;

/**
 * Cross-tick identity resolution (ADR-0017). After within-tick clustering, each
 * Cluster is matched against recent stored Stories of the same Topic: the
 * closest stored embedding above the threshold is escalated to the Reasoner, and
 * on a confirmed match the Cluster adopts that Story's id and absorbs its prior
 * member Raw Items so it accretes corroboration across ticks. Otherwise it gets a
 * fresh deterministic id. The representative vector rides along for persistence.
 */
export interface IdentifiedCluster {
  /** The Story id this Cluster resolves to (existing match, or a fresh storyIdOf). */
  readonly id: string;
  readonly cluster: Cluster;
  /** The Cluster's representative embedding, stored after upsert for future ticks. */
  readonly vector: number[];
}

export interface ResolveDeps {
  readonly storyRepo: StoryRepo;
  readonly rawItemRepo: RawItemRepo;
  readonly llm: PipelineReasoner;
  readonly clock: Clock;
  /** Structured-log sink (src/log/logger.ts); absent ⇒ nullLogger (tests). */
  readonly log?: Logger;
}

export interface ResolveOptions {
  /** Cosine similarity above which a stored Story is a candidate match (ADR-0007). */
  readonly candidateThreshold: number;
  /** How far back to consider stored Stories for a match. */
  readonly recentWindowHours: number;
  /**
   * Match across ALL Topics rather than only the Cluster's own Topic (ADR-0038).
   * The same event is often classified inconsistently across sources (an
   * earthquake as Climate vs Geopolitics), so a same-Topic gate blocks the merge.
   * The LLM confirm + high threshold still guard against false merges. Off ⇒
   * legacy same-Topic behaviour.
   */
  readonly crossTopic?: boolean;
  /** Max concurrent confirm calls; defaults to DEFAULT_CONFIRM_CONCURRENCY. */
  readonly confirmConcurrency?: number;
  /**
   * Entity-relaxed matching band (ADR-0036, extended cross-tick). Different
   * Sources cover one event on different ticks with very different phrasings (a
   * Wikipedia sentence vs a GDACS alert title vs a Guardian headline), so most
   * cross-SOURCE corroboration must accrete HERE — yet the strict cosine bar
   * alone rarely proposes those pairs, which is why major events sat at
   * corroboration 0. A candidate whose similarity lands in
   * [relaxedThreshold, candidateThreshold) is still escalated to the Reasoner
   * when it shares >= relaxedMinSharedEntities named entities/figures with the
   * stored Story. Precision holds: more shared evidence is demanded exactly
   * where the cosine is trusted less (including >=1 shared NON-numeric anchor),
   * and the confirm remains the final guard. OMIT to disable — the composition
   * root wires it from `dedup.entityBlocking` so the config kill-switch governs
   * both the within-tick and the cross-tick relaxation together.
   */
  readonly relaxedThreshold?: number;
  readonly relaxedMinSharedEntities?: number;
}

/** Shared-entity floor for the relaxed band when only the threshold is set. */
const DEFAULT_RELAXED_MIN_SHARED = 2;

/**
 * The closest stored vector above `threshold`, or null. Pure: the matching heart
 * of cross-tick dedup, separately testable from the DB/LLM orchestration.
 */
export function bestMatch(
  vector: readonly number[],
  candidates: readonly StoredVector[],
  threshold: number,
): string | null {
  const closest = closestCandidate(vector, candidates);
  return closest && closest.similarity >= threshold ? closest.storyId : null;
}

/** The single closest stored vector with its similarity, or null when empty. */
function closestCandidate(
  vector: readonly number[],
  candidates: readonly StoredVector[],
): { storyId: string; similarity: number } | null {
  let bestId: string | null = null;
  let best = -Infinity;
  for (const candidate of candidates) {
    const sim = cosine(vector, candidate.vector);
    if (sim > best) {
      best = sim;
      bestId = candidate.storyId;
    }
  }
  return bestId === null ? null : { storyId: bestId, similarity: best };
}

const refKey = (ref: RawItemRef): string => `${ref.source}:${ref.externalId}`;

export async function resolve(
  clusters: readonly Cluster[],
  embedded: readonly EmbeddedItem[],
  deps: ResolveDeps,
  opts: ResolveOptions,
): Promise<IdentifiedCluster[]> {
  const log = deps.log ?? nullLogger;
  const vectorByItem = new Map(embedded.map((e) => [refKey(e.item), e.vector]));
  const sinceMs = deps.clock.now() - opts.recentWindowHours * HOUR_MS;

  // Fetch recent stored vectors ONCE, not once per cluster (ADR-0049). The old
  // per-cluster fetch issued ~one identical large Turso read per cluster (~200/
  // tick) — the dominant cause of multi-minute ticks. Memoize by the query key:
  // a single fetch when crossTopic, else one per distinct Topic. The Promise is
  // stored synchronously before any await, so concurrent callers share one query.
  const candidatesByKey = new Map<string, Promise<StoredVector[]>>();
  const candidatesFor = (topic: Topic): Promise<StoredVector[]> => {
    const key = opts.crossTopic ? '' : topic;
    let p = candidatesByKey.get(key);
    if (!p) {
      p = deps.storyRepo.recentVectors({ ...(opts.crossTopic ? {} : { topic }), sinceMs });
      candidatesByKey.set(key, p);
    }
    return p;
  };

  // The entity-relaxed band's knobs (see ResolveOptions): absent ⇒ the band is
  // OFF and only the strict cosine bar escalates. The floor never sits above
  // the strict bar, so a stricter-than-default candidateThreshold config
  // cannot accidentally widen the relaxed band.
  const relaxedBar =
    opts.relaxedThreshold !== undefined
      ? Math.min(opts.relaxedThreshold, opts.candidateThreshold)
      : opts.candidateThreshold;
  const relaxedMinShared = opts.relaxedMinSharedEntities ?? DEFAULT_RELAXED_MIN_SHARED;

  // Confirm-veto counters — cheap precision evidence for the matching bands.
  const confirms = { accepted: 0, vetoed: 0 };

  // Resolve each Cluster independently and concurrently — this pass only READS
  // the store (writes happen later in the upsert loop), so bounded-parallel
  // matching is safe and keeps a tick's wall-time under the interval (ADR-0038).
  const resolved = await mapWithConcurrency(
    clusters,
    opts.confirmConcurrency ?? DEFAULT_CONFIRM_CONCURRENCY,
    async (cluster): Promise<IdentifiedCluster> => {
      const rep = representativeOf(cluster);
      const vector = vectorByItem.get(refKey(rep)) ?? [];

      const candidates = await candidatesFor(cluster.topic);
      const closest = closestCandidate(vector, candidates);

      if (closest && closest.similarity >= relaxedBar) {
        const existing = await deps.storyRepo.get(closest.storyId);
        // Below the strict bar the cosine alone isn't trusted: demand shared
        // entities with the stored Story — at least one of them a NON-numeric
        // anchor (numbers alone can't tell two 7.1 quakes apart, ADR-0054) —
        // before spending a confirm.
        const shared =
          closest.similarity >= opts.candidateThreshold
            ? null
            : sharedEntityStats(
                extractEntities(dedupText(rep)),
                extractEntities(`${existing?.title ?? ''} ${existing?.summary ?? ''}`),
              );
        const escalate =
          existing !== null &&
          (shared === null || (shared.total >= relaxedMinShared && shared.nonNumeric >= 1));
        if (existing && escalate) {
          // Give the confirm the stored Story's summary as its body snippet —
          // title-only comparisons veto legitimate cross-outlet matches.
          const confirmed = await deps.llm.confirmSameStory(
            { title: rep.title, text: rep.text },
            { title: existing.title, text: existing.summary },
          );
          if (confirmed) {
            confirms.accepted += 1;
            const priorItems = await loadItems(existing.memberRefs, deps.rawItemRepo);
            // Keep the accreting Story's own Topic so it doesn't flap tick-to-tick
            // when a later member was classified differently (ADR-0038).
            return {
              id: closest.storyId,
              cluster: { topic: existing.topic, items: mergeItems(cluster.items, priorItems) },
              vector,
            };
          }
          confirms.vetoed += 1;
        }
      }

      return { id: storyIdOf(cluster), cluster, vector };
    },
  );

  if (confirms.accepted + confirms.vetoed > 0) {
    log.info('resolve.confirm.veto', { confirmed: confirms.accepted, vetoed: confirms.vetoed });
  }

  // Two distinct Clusters can resolve to the SAME Story id (both matched one
  // prior Story, or two fresh clusters share a representative). The upsert loop
  // writes by id, so without this the second write would clobber the first and
  // orphan the first's members. Fold same-id results into one (ADR-0038).
  return dedupeById(resolved);
}

/** Merge IdentifiedClusters that share a Story id: union their items, keep the first vector/topic. */
function dedupeById(resolved: readonly IdentifiedCluster[]): IdentifiedCluster[] {
  const byId = new Map<string, IdentifiedCluster>();
  for (const r of resolved) {
    const existing = byId.get(r.id);
    if (!existing) {
      byId.set(r.id, r);
      continue;
    }
    byId.set(r.id, {
      id: r.id,
      cluster: { topic: existing.cluster.topic, items: mergeItems(existing.cluster.items, r.cluster.items) },
      // Prefer a non-empty vector: if the first cluster had no embedding, take the
      // second's, so the merged story stays cross-tick-matchable (ADR-0051).
      vector: existing.vector.length ? existing.vector : r.vector,
    });
  }
  return [...byId.values()];
}

/** Load the persisted Raw Items behind a Story's member refs (skips any missing). */
async function loadItems(
  refs: readonly RawItemRef[],
  repo: RawItemRepo,
): Promise<RawItem[]> {
  const items = await Promise.all(refs.map((ref) => repo.get(ref)));
  return items.filter((i): i is RawItem => i !== null);
}

/** Union current items with prior ones, de-duplicating by (source, externalId). */
function mergeItems(
  current: readonly RawItem[],
  prior: readonly RawItem[],
): RawItem[] {
  const seen = new Set(current.map(refKey));
  return [...current, ...prior.filter((i) => !seen.has(refKey(i)))];
}
